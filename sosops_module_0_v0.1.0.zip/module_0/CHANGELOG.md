# Changelog — Module 0

0.1.0
- monorepo skeleton
- next.js dashboard shell
- env-backed login
- minimal RBAC rails
- file-based audit
