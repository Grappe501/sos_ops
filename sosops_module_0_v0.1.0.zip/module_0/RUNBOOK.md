# Module 0 Runbook

- Login uses AUTH_STAFF_EMAIL and AUTH_STAFF_PASSWORD_BCRYPT.
- Audit writes JSONL to AUDIT_LOG_PATH.

Rollback:
- replace project root with previous zip/tag
