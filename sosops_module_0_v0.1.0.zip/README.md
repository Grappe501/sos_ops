# SOS OPS — Module 0 (Foundation Scaffold)

Run locally:
1) Copy .env.example -> .env.local and set values.
2) pnpm install
3) pnpm dev
4) http://localhost:3000/login

Note: Module 0 uses file-based audit logging. DB-backed audit arrives Module 1.
